"""
Custom exceptions for configuration management.
"""


class ConfigurationError(Exception):
    """
    Custom exception for configuration-related errors.

    This exception provides context about which configuration key caused the error.
    """

    def __init__(self, message: str, config_key: str = None):
        """
        Initialize the exception.

        Args:
            message: The error message.
            config_key: The configuration key that caused the error.
        """
        super().__init__(message)
        self.config_key = config_key
        self.message = message

    def __str__(self) -> str:
        """
        Get the string representation of the exception.

        Returns:
            The formatted error message.
        """
        if self.config_key:
            return f"Configuration error for '{self.config_key}': {self.message}"
        return f"Configuration error: {self.message}"
