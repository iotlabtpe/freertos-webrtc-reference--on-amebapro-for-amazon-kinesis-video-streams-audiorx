"""
Module for knowledge base configuration management.
"""

from enum import Enum
from typing import Any, Dict
from collections import defaultdict

from agent.utility import Log

# Get logger instance
logger = Log().get_logger(__name__)


class KnowledgeBaseProvider(str, Enum):
    bedrock = "bedrock"


class KnowledgeBaseConfigLookup:
    _instance = None
    _knowledge_bases: Dict[KnowledgeBaseProvider, Dict[str, Dict[str, Any]]] = (
        defaultdict(dict)
    )

    def __new__(cls):
        """Ensure only one instance exists (Singleton pattern)."""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    @classmethod
    def add(
        cls,
        provider: KnowledgeBaseProvider,
        knowledge_base_id: str,
        config: Dict[str, Any],
    ) -> None:
        """
        Add a new knowledge base configuration to the lookup table.

        Args:
            provider: The knowledge base provider
            knowledge_base_id: Unique identifier for the knowledge base
            config: Configuration dictionary for the knowledge base
        """
        cls._knowledge_bases[provider][knowledge_base_id] = config
        logger.debug(
            "Added knowledge base config for provider %s with ID %s",
            provider,
            knowledge_base_id,
        )

    @classmethod
    def lookup(
        cls, provider: KnowledgeBaseProvider, knowledge_base_id: str
    ) -> Dict[str, Any]:
        """
        Retrieve a knowledge base configuration from the lookup table.

        Args:
            provider: The knowledge base provider
            knowledge_base_id: Unique identifier for the knowledge base

        Returns:
            The configuration dictionary for the specified knowledge base

        Raises:
            KeyError: If the provider or knowledge base ID doesn't exist
        """
        try:
            return cls._knowledge_bases[provider][knowledge_base_id]
        except KeyError:
            if provider not in cls._knowledge_bases:
                raise KeyError(
                    f"Provider {provider} not found in knowledge base config lookup"
                )
            raise KeyError(
                f"Knowledge base ID {knowledge_base_id} not found for provider {provider}"
            )
