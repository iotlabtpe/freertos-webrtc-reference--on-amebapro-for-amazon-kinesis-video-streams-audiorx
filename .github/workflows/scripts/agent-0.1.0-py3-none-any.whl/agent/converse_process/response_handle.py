"""
Module defining the base class for response handling.
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional, Tuple

from .stop_reason import StopReason


class BaseResponseHandler(ABC):
    """
    Abstract base class for response handling.

    This class defines the interface for all response handlers
    that process responses from different LLM providers.
    """

    @abstractmethod
    def process_stream_response(
        self, response: Dict[str, Any]
    ) -> Tuple[Optional[StopReason], Dict[str, Any]]:
        """
        Process a streaming response from an LLM provider.

        Args:
            response: The streaming response from the LLM provider.

        Returns:
            Tuple containing:
                - The reason why the model stopped generating text.
                - The processed message.
        """
        pass
