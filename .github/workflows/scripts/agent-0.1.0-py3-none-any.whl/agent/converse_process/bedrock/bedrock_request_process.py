"""
Module for handling requests to Amazon Bedrock.
"""

import time
from typing import Any, Dict, List

import boto3

from agent.config_management import PlatformConfig
from agent.constants.converse import (
    AGENT_CONVERSE_MAX_RETRIES,
    AGENT_CONVERSE_RETRY_SECONDS,
)
from agent.utility import Log

from ..request_process import BaseRequestProcessor

# Get logger instance
log = Log()
logger = log.get_logger(__name__)


class BedrockRequestProcessor(BaseRequestProcessor):
    """
    Class to handle requests to Amazon Bedrock.

    This class is responsible for sending requests to Amazon Bedrock
    and handling any errors or retries that may be needed.
    """

    def __init__(
        self,
        tool_config: Dict[str, Any],
        system_prompt: List[Dict[str, Any]],
        platform_config: PlatformConfig,
    ):
        """
        Initialize the BedrockRequestProcessor.

        Args:
            tool_config: Tool information to send to the model.
            system_prompt: The system prompt to use.
            platform_config: The LLM provider configuration.
        """
        super().__init__(tool_config, system_prompt, platform_config)

        # Initialize Bedrock client
        self.bedrock_client = boto3.Session(**self.platform_config.env).client(
            "bedrock-runtime"
        )

    def send_request(self, messages: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Send a request to Amazon Bedrock with retry logic for throttling.

        Args:
            messages: The messages to send to the model.

        Returns:
            The response from Amazon Bedrock.
        """
        # Define error mappings for cleaner exception handling
        error_mappings = {
            self.bedrock_client.exceptions.ThrottlingException: {
                "type": "throttling",
                "message": "Throttling...",
            },
            self.bedrock_client.exceptions.ServiceUnavailableException: {
                "type": "service unavailable",
                "message": "Service unavailable temporarily...",
            },
            self.bedrock_client.exceptions.InternalServerException: {
                "type": "internal server error",
                "message": "Service failed temporarily...",
            },
        }

        retryable_exceptions = tuple(error_mappings.keys())

        for attempt in range(1, AGENT_CONVERSE_MAX_RETRIES + 1):
            try:
                return self.bedrock_client.converse_stream(
                    modelId=self.platform_config.model,
                    messages=messages,
                    toolConfig=self.tool_config,
                    system=self.system_prompt,
                )
            except retryable_exceptions as err:
                error_info = error_mappings[type(err)]

                log.console.print(error_info["message"], style="bright_black")
                logger.warning(
                    "Bedrock API %s, retrying in %d seconds (attempts: %d/%d)",
                    error_info["type"],
                    AGENT_CONVERSE_RETRY_SECONDS,
                    attempt,
                    AGENT_CONVERSE_MAX_RETRIES,
                )

                if attempt == AGENT_CONVERSE_MAX_RETRIES:
                    logger.error(
                        "Maximum retry attempts (%d) reached",
                        AGENT_CONVERSE_MAX_RETRIES,
                    )
                    raise

                time.sleep(AGENT_CONVERSE_RETRY_SECONDS)
            except Exception as err:
                logger.error("Bedrock API request failed: %s", str(err))
                raise
