"""
Module containing built-in Bedrock knowledge base RAG tools.
"""

from typing import Any, Dict

import boto3

from agent.config_management.knowledge_base_config_lookup import (
    KnowledgeBaseConfigLookup,
)
from agent.tool_management.model import (
    InputSchema,
    InputSchemaJson,
    InputSchemaProperty,
    ToolConfig,
    ToolHandler,
    ToolResult,
    ToolSpec,
)


class BedrockKnowledgeBaseRetrievalHandler(ToolHandler):
    """
    A tool handler for interacting with Amazon Bedrock Knowledge Base.

    This handler provides functionality to query and retrieve information from Bedrock Knowledge Base.
    """

    @classmethod
    def schema(cls) -> ToolConfig:
        """
        Define the tool schema.

        Returns:
            The tool configuration.
        """
        return ToolConfig(
            toolSpec=ToolSpec(
                name="builtin_bedrock_knowledge_base_retrieval",
                description="Query a AWS Bedrock knowledge base with a natural language question and retrieve relevant information",
                inputSchema=InputSchema(
                    json=InputSchemaJson(
                        properties={
                            "knowledge_base_id": InputSchemaProperty(
                                type="string",
                                description="The ID of the Bedrock knowledge base to query",
                            ),
                            "query": InputSchemaProperty(
                                type="string",
                                description="The natural language query to send to the knowledge base",
                            ),
                            "max_results": InputSchemaProperty(
                                type="integer",
                                description="The maximum number of results to retrieve. Default is 5 if not specified.",
                            ),
                        },
                        required=["knowledge_base_id", "query"],
                    )
                ),
            )
        )

    @classmethod
    async def execute(cls, tool: Dict[str, Any]) -> ToolResult:
        """
        Execute a query against a Bedrock knowledge base.

            tool: Dictionary containing the tool configuration with:
                - knowledge_base_id: ID of the Bedrock knowledge base
                - query: Natural language query string
                - max_results: Maximum number of results to return (optional)

        Returns:
            ToolResult containing the retrieved knowledge base responses
        """
        # Get tool parameters
        knowledge_base_id = tool["input"]["knowledge_base_id"]
        query = tool["input"]["query"]
        max_results = tool["input"].get("max_results", 5)

        # Get bedrock knowledge config from agent configuration
        knowledge_config = KnowledgeBaseConfigLookup().lookup(
            provider="bedrock", knowledge_base_id=knowledge_base_id
        )

        # Initialize Bedrock client
        bedrock = boto3.Session(**knowledge_config).client("bedrock-agent-runtime")

        # Query the knowledge base
        response = bedrock.retrieve(
            knowledgeBaseId=knowledge_base_id,
            retrievalQuery={"text": query},
            retrievalConfiguration={
                "vectorSearchConfiguration": {"numberOfResults": max_results}
            },
        )

        # Extract and format results
        results = [
            {
                "text": result["content"].get("text", ""),
                "score": result.get("score", 0),
                "metadata": {
                    k: v
                    for k, v in result.get("metadata", {}).items()
                    if not k.startswith("x-amz-bedrock-kb-")
                },
            }
            for result in response.get("retrievalResults", [])
            if "content" in result and result["content"].get("type") == "TEXT"
        ]

        result_content = {
            "content": results,
            "metadata": {
                "knowledge_base_id": knowledge_base_id,
                "query": query,
                "result_count": len(results),
            },
        }

        return ToolResult(
            toolUseId=tool["toolUseId"], content=[{"text": f"{result_content}"}]
        )
