#!/usr/bin/env python3
"""
Interactive CLI for the conversation agent with tool support.
"""

import argparse
import asyncio
import os
import sys

from agent.cli import AgentCLI
from agent.constants.agent import CONFIG_DIR
from agent.utility import Log

# Configure logging
log = Log()


async def main() -> None:
    """
    Main entry point for the conversation agent CLI.
    """
    parser = argparse.ArgumentParser(description="Conversation agent CLI")
    parser.add_argument(
        "--config-dir",
        "-c",
        type=str,
        default=CONFIG_DIR,
        help="Path to the configuration directory (contains config.yaml)",
    )
    parser.add_argument(
        "--query",
        "-q",
        type=str,
        default=None,
        help="Send a query to the agent",
    )
    parser.add_argument(
        "--log-level",
        "-l",
        type=str,
        default="WARN",
        help="Set log level (DEBUG, INFO, WARN, ERROR)",
    )
    args = parser.parse_args()

    # Set log level from command line argument
    log.set_level(args.log_level)

    try:
        agent_cli = AgentCLI(os.path.abspath(args.config_dir))

        if not args.query:
            await agent_cli.run()
        else:
            await agent_cli.run_query(args.query)
    except KeyboardInterrupt:
        log.console.print("Exiting due to user interrupt")
        return 1
    except Exception as err:
        # Log to file with full traceback
        log.logger.exception("Unhandled error: %s", str(err))
        # Print to console without traceback
        log.console.print(f"[bold red]Error:[/bold red] {str(err)}")
        return 1

    return 0


def main_wrapper():
    """
    Non-async wrapper for the main function to be used as an entry point.
    This allows the package to be run with `uv run git+${URL}`.
    """
    return sys.exit(asyncio.run(main()))


if __name__ == "__main__":
    main_wrapper()
