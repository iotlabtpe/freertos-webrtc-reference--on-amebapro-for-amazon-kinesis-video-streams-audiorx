"""
Constants for system prompts and other prompt-related content.
"""

# Knowledge base usage prompt template
KNOWLEDGE_BASE_USAGE_PROMPT = """\n
## Built-in Knowledge Base Tool Usage

### Available Knowledge Base Tools

The following knowledge base tool is available:

- builtin_bedrock_knowledge_base_retrieval: Use this tool ONLY for knowledge bases with provider 'bedrock'

### When to Use Knowledge Base Tools

You should ONLY use the knowledge base tools when ALL of these conditions are met:
1. You need to retrieve specific information from one of the knowledge bases listed below
2. You must use ONLY the EXACT knowledge base IDs listed below - DO NOT create, modify, or guess any IDs
3. The knowledge base description clearly indicates it contains information relevant to the query
4. The knowledge base provider matches the tool you're using (bedrock for builtin_bedrock_knowledge_base_retrieval)

### CRITICAL: Knowledge Base ID Usage Rules

- NEVER invent, modify, or guess knowledge base IDs
- ONLY use the EXACT IDs as they appear in the list below
- If no ID in the list seems appropriate, DO NOT use the knowledge base tool
- Before using any ID, verify it exists in the list below

### Available Knowledge Bases

{kb_list_placeholder}
"""