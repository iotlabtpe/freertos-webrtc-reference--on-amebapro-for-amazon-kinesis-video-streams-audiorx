"""
Constants related to MCP (Model Context Protocol) functionality.
"""

# Tool name prefix for MCP stdio tools
MCP_STDIO_PREFIX = "mcp_"
