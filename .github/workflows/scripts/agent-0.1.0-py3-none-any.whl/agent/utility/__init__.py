"""
Utility package for common functionality used across the project.
"""

from .log import Log

__all__ = ["Log"]
