"""
Unified logging module for the project.

This module provides a singleton Log class that combines rich console output
and structured logging. It offers two main ways to log information:
1. Console: For user-facing information displayed on stdout
2. Logger: For internal information useful for debugging and development

Usage:
    from src.utility.log import Log

    # Get the singleton instance
    log = Log()

    # User-facing information
    log.console.print("Processing request...", style="bold green")

    # Developer/debug information
    log.logger.info("Request details: %s", request_data)
    log.logger.warning("Potential issue detected")
    log.logger.error("Failed to process request")
"""

import logging
import os
from typing import Optional

from rich.console import Console
from rich.logging import RichHandler

from agent.constants.log import LOGGER_NAME


class Log:
    """
    Singleton class for unified logging across the project.

    Provides both rich console output for user-facing information
    and structured logging for development and debugging.
    """

    _instance: Optional["Log"] = None

    def __new__(cls, log_file: str = "agent.log") -> "Log":
        """
        Create a singleton instance of the Log class.

        Args:
            log_file: Path to the log file (default: agent.log)

        Returns:
            The singleton Log instance
        """
        if cls._instance is None:
            # Ensure log directory exists
            log_dir = os.path.dirname(log_file)
            if log_dir and not os.path.exists(log_dir):
                os.makedirs(log_dir)

            cls._instance = super(Log, cls).__new__(cls)
            cls._instance._initialize(log_file)
        return cls._instance

    def _initialize(self, log_file: str) -> None:
        """Initialize the console and logger components.

        Args:
            log_file: Path to the log file
        """
        # Create console for terminal output
        self.console = Console()

        # Create file console for log file output
        file_console = Console(file=open(log_file, "a"), highlight=False)
        file_handler = RichHandler(
            rich_tracebacks=True, console=file_console, markup=True
        )
        file_handler.setFormatter(logging.Formatter("%(message)s"))
        file_handler.setLevel(logging.INFO)

        # Get the root logger
        self.logger = logging.getLogger(LOGGER_NAME)
        self.logger.addHandler(file_handler)

    def set_level(self, level: int) -> None:
        """
        Set the logging level.

        Args:
            level: The logging level (e.g., logging.DEBUG, logging.INFO)
        """
        self.logger.setLevel(level)

    def get_logger(self, name: str) -> logging.Logger:
        """
        Get a named logger that inherits from the root logger.

        Args:
            name: The name for the logger, typically __name__ of the calling module

        Returns:
            A named logger instance
        """
        return logging.getLogger(f"{LOGGER_NAME}.{name}")
