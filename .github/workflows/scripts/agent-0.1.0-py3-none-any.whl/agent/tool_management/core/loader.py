"""
Module for loading tool handlers from specified directories.
"""

import glob
import importlib
import inspect
import os
import sys
from typing import List, Type

from agent.utility import Log

from ..model import ToolHandler

# Get logger instance
log = Log()
logger = log.get_logger(__name__)


class ToolLoader:
    """Loader for tool handlers from specified directories."""

    @staticmethod
    def load_from_path(
        path: str, parent_package: str = None
    ) -> List[Type[ToolHandler]]:
        """
        Import all ToolHandler subclasses from modules in the specified path.

        Args:
            path: Directory path to search for tool handlers
            parent_package: Optional import path for the modules

        Returns:
            List of tool handler classes found
        """
        py_files = glob.glob(os.path.join(path, "*.py"))
        classes = []

        for py_file in py_files:
            if os.path.basename(py_file) == "__init__.py":
                continue

            try:
                module_name = os.path.splitext(os.path.basename(py_file))[0]
                if parent_package:
                    module_name = f"{parent_package}.{module_name}"

                spec = importlib.util.spec_from_file_location(module_name, py_file)

                if spec and spec.loader:
                    module = importlib.util.module_from_spec(spec)
                    sys.modules[module_name] = module
                    spec.loader.exec_module(module)

                    classes.extend(
                        [
                            cls
                            for _, cls in inspect.getmembers(module)
                            if inspect.isclass(cls)
                            and issubclass(cls, ToolHandler)
                            and cls != ToolHandler
                        ]
                    )
            except ImportError as e:
                logger.warning("Failed to import module %s: %s", module_name, str(e))

        logger.debug("Loaded %d tool handlers from %s", len(classes), path)
        return classes
