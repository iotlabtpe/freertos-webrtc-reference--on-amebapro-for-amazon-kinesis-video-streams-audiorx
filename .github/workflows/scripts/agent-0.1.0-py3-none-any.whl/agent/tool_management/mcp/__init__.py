"""
Package for Machine Comprehension Protocol (MCP) integration.
"""

from .server_manager import McpServerManager

__all__ = [
    "McpServerManager",
]
