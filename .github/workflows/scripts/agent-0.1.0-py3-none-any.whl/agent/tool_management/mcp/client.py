"""
Client for interacting with Machine Comprehension Protocol (MCP) servers.
"""

from contextlib import AsyncExitStack
import logging
from typing import Any, List

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

logger = logging.getLogger(__name__)


class McpClient:
    """
    Client for interacting with MCP servers.

    This class provides an async context manager interface for connecting to
    and interacting with MCP servers using the stdio protocol.
    """

    def __init__(self, server_params: StdioServerParameters):
        """
        Initialize the MCP client.

        Args:
            server_params: Parameters for connecting to the stdio server
        """
        self.server_params = server_params
        self._exit_stack = None

    async def __aenter__(self):
        """
        Async context manager entry.

        Returns:
            Self after establishing connection
        """
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """
        Async context manager exit.

        Ensures proper cleanup of resources.
        """
        if self._exit_stack:
            await self._exit_stack.aclose()

    async def connect(self):
        """
        Establish connection to MCP server.

        Initializes the client session for communication.
        """
        try:
            self._exit_stack = AsyncExitStack()
            self.read, self.write = await self._exit_stack.enter_async_context(
                stdio_client(self.server_params)
            )
            self.session = await self._exit_stack.enter_async_context(
                ClientSession(self.read, self.write)
            )
            await self.session.initialize()
        except Exception as e:
            logger.error("Failed to connect to MCP server: %s", str(e))
            await self._exit_stack.aclose()

    async def get_available_tools(self) -> List[Any]:
        """
        List available tools from the MCP server.

        Returns:
            List of available tools

        Raises:
            RuntimeError: If not connected to MCP server
        """
        if not self.session:
            raise RuntimeError("Not connected to MCP server")

        results = await self.session.list_tools()
        return results.tools

    async def call_tool(self, tool_name: str, arguments: dict) -> Any:
        """
        Call a tool with given arguments.

        Args:
            tool_name: Name of the tool to call
            arguments: Arguments to pass to the tool

        Returns:
            Result from the tool execution

        Raises:
            RuntimeError: If not connected to MCP server
        """
        if not self.session:
            raise RuntimeError("Not connected to MCP server")

        result = await self.session.call_tool(tool_name, arguments=arguments)
        return result
